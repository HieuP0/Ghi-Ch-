package com.mycompany.myapp2;

import android.app.*;
import android.os.*;
import android.widget.*;
import android.view.View.*;
import android.view.*;

public class MainActivity extends Activity 
{
    ImageButton n1;
    ImageButton n2;
    ImageButton n3;
    ImageButton n4;
    ImageButton n5;
    ImageButton n6;
    ImageButton n7;
    ImageButton n8;
    ImageButton n9;
    ImageButton n10;
    ImageButton n11;
    ImageButton n12;
    ImageButton n13;
    ImageButton n14;
    ImageButton n15;
    ImageButton n16;
    int luot;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        n1 =(ImageButton) findViewById(R.id.n1);
        n1.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
					int sn1;
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n1.setBackgroundResource(R.drawable.x);
						sn1 =1;
                    }
                    else
                    {
                        n1.setBackgroundResource(R.drawable.o);
						sn1 =2;
                    }
                    luot++;
					
                }
            });
        n2 =(ImageButton) findViewById(R.id.n2);
        n2.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
				int ns2;
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n2.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n2.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n3 =(ImageButton) findViewById(R.id.n3);
        n3.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n3.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n3.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
            n4 =(ImageButton) findViewById(R.id.n4);
            n4.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n4.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n4.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n5 =(ImageButton) findViewById(R.id.n5);
        n5.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n5.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n5.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n6 =(ImageButton) findViewById(R.id.n6);
        n6.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n6.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n6.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n7 =(ImageButton) findViewById(R.id.n7);
        n7.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n7.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n7.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n8 =(ImageButton) findViewById(R.id.n8);
        n8.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n8.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n8.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n9 =(ImageButton) findViewById(R.id.n9);
        n9.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n9.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n9.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n10 =(ImageButton) findViewById(R.id.n10);
        n10.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n10.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n10.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n11 =(ImageButton) findViewById(R.id.n11);
        n11.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n11.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n11.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n12 =(ImageButton) findViewById(R.id.n12);
        n12.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n12.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n12.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n13 =(ImageButton) findViewById(R.id.n13);
        n13.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n13.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n13.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n14 =(ImageButton) findViewById(R.id.n14);
        n14.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n14.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n14.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n15 =(ImageButton) findViewById(R.id.n15);
        n15.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n15.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n15.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
        n16 =(ImageButton) findViewById(R.id.n16);
        n16.setOnClickListener(new OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    luot =luot % 2;
                    if (luot ==0)
                    {
                        n16.setBackgroundResource(R.drawable.x);
                    }
                    else
                    {
                        n16.setBackgroundResource(R.drawable.o);
                    }
                    luot++;
                }
            });
           if ()
		   {
			   
		   }
        
    }
}
